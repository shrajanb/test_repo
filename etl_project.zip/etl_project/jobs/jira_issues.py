"""Job to sync Jira issues into the reporting database."""

from __future__ import annotations

import datetime as dt
from typing import List

from ..common.logging import get_logger
from ..common.checkpoints import get_checkpoint, set_checkpoint
from ..connectors import JiraClient
from ..loaders import insert_rows, upsert_issues

logger = get_logger(__name__)


def run() -> None:
    """Fetch Jira issues updated since the last checkpoint and persist them."""
    source_key = "jira_issues"
    since = get_checkpoint(source_key)
    logger.info("Starting Jira issues job (since=%s)", since)
    client = JiraClient()
    issues = client.fetch_issues_incremental(since)
    if not issues:
        logger.info("No Jira issues to process.")
        return
    # Insert raw data into staging.  Use issue_key as the identifier.
    insert_rows("stg_jira_issues", issues, id_field="issue_key")
    # Upsert into core tables
    upsert_issues(issues)
    # Compute new checkpoint: max updated timestamp
    updated_values = [row.get("updated") for row in issues if row.get("updated")]
    if updated_values:
        new_since = max(updated_values)
        set_checkpoint(source_key, new_since)
        logger.info("Updated Jira issues checkpoint to %s", new_since)
    else:
        logger.warning("No updated timestamps found in Jira issues response.")


if __name__ == "__main__":  # pragma: no cover
    run()