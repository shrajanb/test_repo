"""Job to sync Jenkins build information into the reporting database."""

from __future__ import annotations

from ..common.logging import get_logger
from ..common.checkpoints import get_checkpoint, set_checkpoint
from ..connectors import JenkinsClient
from ..loaders import insert_rows, upsert_builds

logger = get_logger(__name__)


def run() -> None:
    """Fetch Jenkins builds since the last checkpoint and persist them."""
    source_key = "jenkins_builds"
    since_str = get_checkpoint(source_key)
    # Jenkins timestamps are in milliseconds; convert since_str if present
    since_ms = None
    if since_str:
        try:
            # Accept either ISO string or epoch milliseconds stored as string
            if since_str.isdigit():
                since_ms = int(since_str)
            else:
                import datetime as dt
                dt_obj = dt.datetime.fromisoformat(since_str)
                since_ms = int(dt_obj.timestamp() * 1000)
        except Exception:
            logger.warning("Invalid Jenkins checkpoint format: %s", since_str)
    logger.info("Starting Jenkins builds job (since=%s)", since_ms)
    client = JenkinsClient()
    builds = client.fetch_builds_since(since_ms)
    if not builds:
        logger.info("No Jenkins builds to process.")
        return
    # Compose a unique id: job#buildnumber
    for build in builds:
        job_name = build.get("job_name")
        number = build.get("build_number")
        build["id"] = f"{job_name}#{number}" if job_name and number is not None else str(number)
    insert_rows("stg_jenkins_builds", builds, id_field="id")
    upsert_builds(builds)
    # Update checkpoint to max timestamp (ms) among builds
    timestamps = [b.get("timestamp") for b in builds if b.get("timestamp")]
    if timestamps:
        new_since_ms = max(timestamps)
        # Persist as string for flexibility
        set_checkpoint(source_key, str(new_since_ms))
        logger.info("Updated Jenkins builds checkpoint to %s", new_since_ms)
    else:
        logger.warning("No timestamps found in Jenkins builds response.")


if __name__ == "__main__":  # pragma: no cover
    run()