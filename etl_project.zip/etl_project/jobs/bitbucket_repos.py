"""Job to sync Bitbucket repositories into the reporting database."""

from __future__ import annotations

from ..common.logging import get_logger
from ..common.checkpoints import get_checkpoint, set_checkpoint
from ..connectors import BitbucketClient
from ..loaders import insert_rows, upsert_repos

logger = get_logger(__name__)


def run() -> None:
    """Fetch Bitbucket repositories and persist them.

    Bitbucket does not provide a concept of last updated timestamp on
    repositories that can be easily used for incremental sync.  This
    job therefore fetches all repositories each run and updates the
    checkpoint to the current timestamp.  In practice you may wish to
    implement incremental logic based on ``updated_on``.
    """
    source_key = "bitbucket_repos"
    since = get_checkpoint(source_key)
    logger.info("Starting Bitbucket repos job (previous run at %s)", since)
    client = BitbucketClient()
    repos = client.fetch_repositories()
    if not repos:
        logger.info("No Bitbucket repos to process.")
        return
    # Use repository full name as id for staging
    for repo in repos:
        repo["id"] = repo.get("full_name") or repo.get("name")
    insert_rows("stg_bitbucket_repos", repos, id_field="id")
    upsert_repos(repos)
    # Set checkpoint to current UTC timestamp for informational purposes
    import datetime as dt
    now_str = dt.datetime.utcnow().isoformat()
    set_checkpoint(source_key, now_str)
    logger.info("Updated Bitbucket repos checkpoint to %s", now_str)


if __name__ == "__main__":  # pragma: no cover
    run()