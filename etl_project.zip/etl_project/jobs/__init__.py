"""Job definitions for the ETL project.

This package exposes functions that perform end‑to‑end ETL for each
source system.  Each job should fetch incremental data from its
connector, store raw records in a staging table, upsert into core
tables and update its checkpoint.  Jobs must be idempotent: if run
twice with the same checkpoint they should not duplicate data.

To execute a job manually, run ``python -m etl_project.jobs.<name>``
or call the ``run`` function from ``main.py``.
"""

from .jira_issues import run as run_jira_issues  # noqa: F401
from .github_prs import run as run_github_prs  # noqa: F401
from .bitbucket_repos import run as run_bitbucket_repos  # noqa: F401
from .jenkins_builds import run as run_jenkins_builds  # noqa: F401
from .azure_devops_prs import run as run_azure_devops_prs  # noqa: F401