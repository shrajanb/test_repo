"""Job to sync GitHub pull requests into the reporting database."""

from __future__ import annotations

import datetime as dt
from typing import List

from ..common.logging import get_logger
from ..common.checkpoints import get_checkpoint, set_checkpoint
from ..connectors import GitHubClient
from ..loaders import insert_rows, upsert_pull_requests

logger = get_logger(__name__)


def run() -> None:
    """Fetch GitHub pull requests updated since last checkpoint and persist."""
    source_key = "github_prs"
    since = get_checkpoint(source_key)
    logger.info("Starting GitHub PRs job (since=%s)", since)
    client = GitHubClient()
    prs = client.fetch_pull_requests_incremental(since)
    if not prs:
        logger.info("No GitHub pull requests to process.")
        return
    # For staging, create a unique id per PR across repos: repo#number
    for pr in prs:
        repo = pr.get("repo_full_name")
        number = pr.get("number")
        pr["id"] = f"{repo}#{number}" if repo and number is not None else str(number)
    insert_rows("stg_github_pull_requests", prs, id_field="id")
    upsert_pull_requests(prs)
    # Determine new checkpoint: use max 'updated' value
    updated_values = [row.get("updated") for row in prs if row.get("updated")]
    if updated_values:
        new_since = max(updated_values)
        set_checkpoint(source_key, new_since)
        logger.info("Updated GitHub PRs checkpoint to %s", new_since)
    else:
        logger.warning("No updated timestamps found in GitHub PRs response.")


if __name__ == "__main__":  # pragma: no cover
    run()