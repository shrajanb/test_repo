"""Job to sync Azure DevOps pull requests into the reporting database."""

from __future__ import annotations

from ..common.logging import get_logger
from ..common.checkpoints import get_checkpoint, set_checkpoint
from ..connectors import AzureDevOpsClient
from ..loaders import insert_rows, upsert_pull_requests

logger = get_logger(__name__)


def run() -> None:
    """Fetch Azure DevOps PRs updated since last checkpoint and persist."""
    source_key = "azure_devops_prs"
    since = get_checkpoint(source_key)
    logger.info("Starting Azure DevOps PRs job (since=%s)", since)
    client = AzureDevOpsClient()
    prs = client.fetch_pull_requests_incremental(since)
    if not prs:
        logger.info("No Azure DevOps pull requests to process.")
        return
    # Compose a unique id for staging: project_repo#prid
    for pr in prs:
        project = pr.get("project")
        repo_id = pr.get("repo_id")
        pr_id = pr.get("pr_id")
        pr["id"] = f"{project}/{repo_id}#{pr_id}" if project and repo_id and pr_id is not None else str(pr_id)
    insert_rows("stg_azure_devops_prs", prs, id_field="id")
    upsert_pull_requests(prs)
    # Determine new checkpoint: use max created timestamp
    updated_values = [row.get("created") for row in prs if row.get("created")]
    if updated_values:
        new_since = max(updated_values)
        set_checkpoint(source_key, new_since)
        logger.info("Updated Azure DevOps PRs checkpoint to %s", new_since)
    else:
        logger.warning("No creation timestamps found in Azure DevOps PRs response.")


if __name__ == "__main__":  # pragma: no cover
    run()