"""Connector for the Jenkins REST API.

This client retrieves builds from Jenkins.  It assumes that the
instance exposes JSON API endpoints (``/job/{name}/api/json``) and
supports basic authentication.  Only minimal fields are extracted.
"""

import base64
from typing import Dict, List, Optional

from ..common.http import get, APIError
from ..config import settings
from ..common.logging import get_logger

logger = get_logger(__name__)


class JenkinsClient:
    """Simple Jenkins API client supporting basic auth."""

    def __init__(self, base_url: Optional[str] = None, username: Optional[str] = None, api_token: Optional[str] = None) -> None:
        self.base_url = (base_url or settings.JENKINS_BASE).rstrip('/')
        self.username = username or settings.JENKINS_USER
        self.api_token = api_token or settings.JENKINS_API_TOKEN
        if not self.username or not self.api_token:
            raise RuntimeError("Jenkins credentials are not configured. Set JENKINS_USER and JENKINS_API_TOKEN.")

    def _auth_header(self) -> Dict[str, str]:
        auth_str = f"{self.username}:{self.api_token}".encode('utf-8')
        b64 = base64.b64encode(auth_str).decode('ascii')
        return {"Authorization": f"Basic {b64}", "Accept": "application/json"}

    def _list_jobs(self) -> List[Dict]:
        """Return a list of jobs configured in Jenkins."""
        url = f"{self.base_url}/api/json"
        params = {"tree": "jobs[name,url]"}
        try:
            data = get(url, headers=self._auth_header(), params=params)
        except APIError as exc:
            logger.error("Failed to list Jenkins jobs: %s", exc)
            return []
        jobs = data.get("jobs", [])
        return jobs

    def _list_builds(self, job_name: str) -> List[Dict]:
        """Return a list of builds for a specific job."""
        url = f"{self.base_url}/job/{job_name}/api/json"
        params = {"tree": "builds[number,timestamp,result]"}
        try:
            data = get(url, headers=self._auth_header(), params=params)
        except APIError as exc:
            logger.error("Failed to list builds for job %s: %s", job_name, exc)
            return []
        return data.get("builds", [])

    def fetch_builds_since(self, since_ms: Optional[int] = None) -> List[Dict]:
        """Return builds across all jobs whose timestamp is greater than ``since_ms``.

        Jenkins returns timestamps in milliseconds.  If ``since_ms`` is None,
        all builds are returned.
        """
        jobs = self._list_jobs()
        builds: List[Dict] = []
        for job in jobs:
            name = job.get("name")
            if not name:
                continue
            for build in self._list_builds(name):
                ts = build.get("timestamp")  # in ms since epoch
                if since_ms and ts and ts < since_ms:
                    continue
                builds.append({
                    "job_name": name,
                    "build_number": build.get("number"),
                    "timestamp": build.get("timestamp"),
                    "result": build.get("result"),
                    "raw": build,
                })
        logger.info("Fetched %d Jenkins builds", len(builds))
        return builds