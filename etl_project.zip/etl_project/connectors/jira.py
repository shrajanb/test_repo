"""Connector for the Atlassian Jira REST API.

This client encapsulates authentication and pagination logic for Jira.
It supports incremental retrieval of issues updated since a given
timestamp.  Results are returned as simple dictionaries containing
selected fields.  Callers are expected to store the raw JSON if
desired.

Environment variables used:
 - JIRA_BASE: base URL of the Jira instance, e.g. https://jira.example.com
 - JIRA_TOKEN: API token for authentication (Basic auth with email)

The token should be combined with the Jira username or email in the
Authorization header.  Many organisations use a PAT combined with the
user's email: ``Authorization: Basic base64(f"email:{token}")``.
"""

import base64
import datetime as dt
from typing import Dict, List, Optional

from ..common.http import get, APIError
from ..config import settings
from ..common.logging import get_logger

logger = get_logger(__name__)


class JiraClient:
    """Simple Jira REST API client.

    Parameters
    ----------
    base_url: str
        Base URL of the Jira instance, without a trailing slash.
    token: str
        Personal access token.  When combined with the email in
        basic authentication, this grants access to the REST API.
    email: Optional[str]
        Email associated with the token.  If provided, it is used in
        the Basic auth header; otherwise, token-only authentication is
        attempted.  Jira Cloud typically requires email:token.
    """

    def __init__(self, base_url: Optional[str] = None, token: Optional[str] = None, email: Optional[str] = None) -> None:
        self.base_url = (base_url or settings.JIRA_BASE).rstrip('/')
        self.token = token or settings.JIRA_TOKEN
        self.email = email  # may be None if token-only auth is supported
        if not self.token:
            raise RuntimeError("Jira token is not configured. Set JIRA_TOKEN env var.")

    def _auth_header(self) -> Dict[str, str]:
        if self.email:
            # Basic auth: base64(email:token)
            auth_str = f"{self.email}:{self.token}".encode('utf-8')
            b64 = base64.b64encode(auth_str).decode('ascii')
            return {"Authorization": f"Basic {b64}"}
        # Token-only (if supported)
        return {"Authorization": f"Bearer {self.token}"}

    def fetch_issues_incremental(self, since: Optional[str] = None) -> List[Dict]:
        """Return issues updated since the given ISO 8601 timestamp.

        Parameters
        ----------
        since: str or None
            ISO formatted date/time.  If None, all issues are returned.

        Returns
        -------
        List[dict]
            A list of issues with selected fields.  Each record contains
            ``key``, ``summary``, ``status``, ``assignee``, ``updated``, and
            the full JSON payload under ``raw``.
        """
        jql = f"updated >= {since}" if since else None
        start_at = 0
        max_results = 50
        issues: List[Dict] = []
        while True:
            params = {"startAt": start_at, "maxResults": max_results}
            if jql:
                params["jql"] = jql
            url = f"{self.base_url}/rest/api/3/search"
            headers = {"Accept": "application/json"}
            headers.update(self._auth_header())
            try:
                data = get(url, headers=headers, params=params)
            except APIError as exc:
                logger.error("Failed to fetch Jira issues: %s", exc)
                break
            raw_issues = data.get("issues", [])
            for item in raw_issues:
                fields = item.get("fields", {})
                issues.append({
                    "issue_key": item.get("key"),
                    "summary": fields.get("summary"),
                    "status": fields.get("status", {}).get("name"),
                    "assignee": (fields.get("assignee") or {}).get("displayName"),
                    "updated": fields.get("updated"),
                    "raw": item,
                })
            if len(raw_issues) < max_results:
                break
            start_at += max_results
        logger.info("Fetched %d Jira issues", len(issues))
        return issues