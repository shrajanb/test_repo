"""Client libraries for external services.

This package contains thin wrapper classes around the various APIs the
platform integrates with.  Each connector handles authentication,
pagination and incremental fetching of data.  They return Python
dictionaries to be passed into staging and upsert functions.

All connectors rely on the common HTTP helpers which implement
resilient request patterns with retries and basic error handling.
"""

from .jira import JiraClient  # noqa: F401
from .github import GitHubClient  # noqa: F401
from .bitbucket import BitbucketClient  # noqa: F401
from .jenkins import JenkinsClient  # noqa: F401
from .azure_devops import AzureDevOpsClient  # noqa: F401