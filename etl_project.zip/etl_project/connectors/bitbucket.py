"""Connector for the Bitbucket Cloud API.

This client encapsulates authentication and pagination for Bitbucket.
Currently it only supports listing repositories and returning basic
information.  Additional endpoints can be added to fetch pull
requests, commits, etc.  Authentication is performed via OAuth token.
"""

from typing import Dict, List, Optional

from ..common.http import get, APIError
from ..config import settings
from ..common.logging import get_logger

logger = get_logger(__name__)


class BitbucketClient:
    """Simple Bitbucket Cloud API client.

    Parameters
    ----------
    base_url: str
        Base API URL, defaults to ``https://api.bitbucket.org/2.0``.
    token: str
        OAuth access token with read permissions.
    workspace: str
        The workspace (team) name to list repositories from.  If not
        provided, it defaults to the value of ``BITBUCKET_WORKSPACE`` env
        var.
    """

    def __init__(self, base_url: Optional[str] = None, token: Optional[str] = None, workspace: Optional[str] = None) -> None:
        self.base_url = (base_url or settings.BITBUCKET_BASE).rstrip('/')
        self.token = token or settings.BITBUCKET_TOKEN
        import os  # Local import to avoid global dependency if not needed
        self.workspace = workspace or os.getenv("BITBUCKET_WORKSPACE")
        if not self.token:
            raise RuntimeError("Bitbucket token is not configured. Set BITBUCKET_TOKEN env var.")
        if not self.workspace:
            raise RuntimeError("Bitbucket workspace is not configured. Set BITBUCKET_WORKSPACE env var.")

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }

    def fetch_repositories(self) -> List[Dict]:
        """Return basic information about repositories in the workspace."""
        url = f"{self.base_url}/repositories/{self.workspace}"
        params = {"pagelen": 100}
        repos: List[Dict] = []
        next_url: Optional[str] = url
        while next_url:
            try:
                data = get(next_url, headers=self._headers(), params=params)
            except APIError as exc:
                logger.error("Failed to list Bitbucket repos: %s", exc)
                break
            values = data.get("values", [])
            for repo in values:
                repos.append({
                    "uuid": repo.get("uuid"),
                    "name": repo.get("name"),
                    "full_name": repo.get("full_name"),
                    "is_private": repo.get("is_private"),
                    "updated_on": repo.get("updated_on"),
                    "raw": repo,
                })
            next_url = data.get("next")
        logger.info("Fetched %d Bitbucket repos", len(repos))
        return repos