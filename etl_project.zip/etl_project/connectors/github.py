"""Connector for the GitHub REST API.

This client encapsulates authentication and pagination for GitHub.  It
supports incremental retrieval of pull requests updated since a given
timestamp across all repositories in an organisation.  Results are
returned as dictionaries containing selected fields.

GitHub API docs: https://docs.github.com/en/rest
"""

import datetime as dt
from typing import Dict, List, Optional

from ..common.http import get, APIError
from ..config import settings
from ..common.logging import get_logger

logger = get_logger(__name__)


class GitHubClient:
    """Simple GitHub REST API client.

    Parameters
    ----------
    token: str
        Personal access token with ``repo`` scope.
    org: str
        Name of the GitHub organisation whose repos should be scanned.
    """

    def __init__(self, token: Optional[str] = None, org: Optional[str] = None) -> None:
        self.token = token or settings.GITHUB_TOKEN
        self.org = org or settings.GITHUB_ORG
        if not self.token:
            raise RuntimeError("GitHub token is not configured. Set GITHUB_TOKEN env var.")
        if not self.org:
            raise RuntimeError("GitHub organisation is not configured. Set GITHUB_ORG env var.")

    def _headers(self) -> Dict[str, str]:
        return {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self.token}",
        }

    def _list_repositories(self) -> List[Dict]:
        """Return a list of repositories in the organisation."""
        url = f"https://api.github.com/orgs/{self.org}/repos"
        params = {"per_page": 100, "type": "all"}
        repos: List[Dict] = []
        page = 1
        while True:
            params["page"] = page
            try:
                data = get(url, headers=self._headers(), params=params)
            except APIError as exc:
                logger.error("Failed to list GitHub repos: %s", exc)
                break
            if not isinstance(data, list):
                # GH returns a list of repos
                break
            repos.extend(data)
            if len(data) < params["per_page"]:
                break
            page += 1
        logger.info("Found %d GitHub repos", len(repos))
        return repos

    def _list_pull_requests(self, repo_full_name: str, since: Optional[str]) -> List[Dict]:
        """Return pull requests for a single repository updated since ``since``.

        Parameters
        ----------
        repo_full_name: str
            Repository in the form "owner/repo".
        since: str or None
            ISO 8601 timestamp.  If None, all PRs are returned.
        """
        url = f"https://api.github.com/repos/{repo_full_name}/pulls"
        params = {
            "state": "all",
            "sort": "updated",
            "direction": "asc",
            "per_page": 100,
        }
        # GitHub API does not directly support 'since' filter on PRs; we will
        # filter client-side based on the 'updated_at' field.
        prs: List[Dict] = []
        page = 1
        while True:
            params["page"] = page
            try:
                data = get(url, headers=self._headers(), params=params)
            except APIError as exc:
                logger.error("Failed to list PRs for %s: %s", repo_full_name, exc)
                break
            if not isinstance(data, list):
                break
            for pr in data:
                updated_at = pr.get("updated_at")
                if since and updated_at and updated_at < since:
                    continue
                prs.append(pr)
            if len(data) < params["per_page"]:
                break
            page += 1
        return prs

    def fetch_pull_requests_incremental(self, since: Optional[str] = None) -> List[Dict]:
        """Return pull requests across all repos updated since ``since``.

        Each returned record contains ``repo``, ``number``, ``title``, ``state``,
        ``author``, ``updated``, and the full PR JSON under ``raw``.  Because
        the GitHub API does not natively filter by ``since`` on PRs, this
        method filters client-side.
        """
        repos = self._list_repositories()
        all_prs: List[Dict] = []
        for repo in repos:
            full_name = repo.get("full_name")
            if not full_name:
                continue
            prs = self._list_pull_requests(full_name, since)
            for pr in prs:
                all_prs.append({
                    "repo_full_name": full_name,
                    "number": pr.get("number"),
                    "title": pr.get("title"),
                    "state": pr.get("state"),
                    "author": (pr.get("user") or {}).get("login"),
                    "updated": pr.get("updated_at"),
                    "raw": pr,
                })
        logger.info("Fetched %d GitHub pull requests", len(all_prs))
        return all_prs