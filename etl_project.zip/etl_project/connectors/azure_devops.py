"""Connector for Azure DevOps REST API.

This client retrieves work items from Azure DevOps.  It uses a
personal access token (PAT) for authentication.  Currently it only
supports listing pull requests updated since a given timestamp across
all repositories in the organisation.  Additional methods can be
added for builds, releases, etc.
"""

from typing import Dict, List, Optional

from ..common.http import get, APIError
from ..config import settings
from ..common.logging import get_logger

logger = get_logger(__name__)


class AzureDevOpsClient:
    """Simple Azure DevOps REST API client."""

    def __init__(self, org_url: Optional[str] = None, pat: Optional[str] = None) -> None:
        self.org_url = (org_url or settings.AZDO_ORG_URL).rstrip('/')
        self.pat = pat or settings.AZDO_PAT
        if not self.pat:
            raise RuntimeError("Azure DevOps PAT is not configured. Set AZDO_PAT env var.")

    def _auth_header(self) -> Dict[str, str]:
        import base64
        pat_str = f":{self.pat}".encode("utf-8")
        b64 = base64.b64encode(pat_str).decode("ascii")
        return {"Authorization": f"Basic {b64}", "Accept": "application/json"}

    def _list_repositories(self) -> List[Dict]:
        """Return repositories across all projects in the organisation."""
        url = f"{self.org_url}/_apis/git/repositories?api-version=6.0"
        try:
            data = get(url, headers=self._auth_header())
        except APIError as exc:
            logger.error("Failed to list Azure DevOps repositories: %s", exc)
            return []
        repos = data.get("value", [])
        return repos

    def _list_pull_requests(self, project_name: str, repo_id: str, since: Optional[str]) -> List[Dict]:
        """Return pull requests for a repository updated since ``since``.

        Parameters
        ----------
        project_name: str
            Name of the project the repository belongs to.
        repo_id: str
            Identifier of the repository.
        since: str or None
            ISO 8601 timestamp for filtering PRs updated after this time.
        """
        url = f"{self.org_url}/{project_name}/_apis/git/repositories/{repo_id}/pullrequests?api-version=6.0"
        params: Dict[str, str] = {
            "searchCriteria.status": "all",
            "searchCriteria.includeLinks": "false",
        }
        # There is no direct 'updated since' filter; we will filter on client.
        try:
            data = get(url, headers=self._auth_header(), params=params)
        except APIError as exc:
            logger.error(
                "Failed to list PRs for project %s repo %s: %s",
                project_name,
                repo_id,
                exc,
            )
            return []
        prs = []
        for pr in data.get("value", []):
            updated = pr.get("creationDate")  # use creationDate as proxy for updated
            if since and updated and updated < since:
                continue
            prs.append(pr)
        return prs

    def fetch_pull_requests_incremental(self, since: Optional[str] = None) -> List[Dict]:
        """Return pull requests across projects updated since ``since``.

        Each record contains ``project``, ``repo_id``, ``pr_id``, ``title``, ``status``,
        ``creator``, ``creationDate`` and the full raw PR JSON under ``raw``.
        """
        repos = self._list_repositories()
        all_prs: List[Dict] = []
        for repo in repos:
            project = repo.get("project", {}).get("name")
            repo_id = repo.get("id")
            if not project or not repo_id:
                continue
            prs = self._list_pull_requests(project, repo_id, since)
            for pr in prs:
                all_prs.append({
                    "project": project,
                    "repo_id": repo_id,
                    "pr_id": pr.get("pullRequestId"),
                    "title": pr.get("title"),
                    "status": pr.get("status"),
                    "creator": (pr.get("createdBy") or {}).get("displayName"),
                    "created": pr.get("creationDate"),
                    "raw": pr,
                })
        logger.info("Fetched %d Azure DevOps pull requests", len(all_prs))
        return all_prs