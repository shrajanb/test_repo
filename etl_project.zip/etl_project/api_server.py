"""Simple API server to trigger ETL jobs on demand.

This Flask application exposes an endpoint ``/run`` that accepts a JSON
payload with a ``job`` field.  If the job is known, it is submitted
for execution in a background thread pool.  The server immediately
returns a 202 status to acknowledge receipt.

Examples
========

Run the Jira job via curl::

    curl -X POST -H "Content-Type: application/json" -d '{"job":"jira_issues"}' http://localhost:5000/run

Run the GitHub PRs job::

    curl -X POST -H "Content-Type: application/json" -d '{"job":"github_prs"}' http://localhost:5000/run
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from flask import Flask, request, jsonify

from .main import JOBS, run_job
from .config import settings
from .common.logging import get_logger

logger = get_logger(__name__)

app = Flask(__name__)
executor = ThreadPoolExecutor(max_workers=settings.MAX_WORKERS)


@app.route("/run", methods=["POST"])
def run_endpoint():
    payload = request.get_json(silent=True) or {}
    job_name = payload.get("job")
    if not job_name:
        return jsonify({"error": "Missing job name"}), 400
    if job_name not in JOBS:
        return jsonify({"error": f"Unknown job: {job_name}"}), 400
    # Submit job to thread pool
    logger.info("Submitting job %s via API", job_name)
    executor.submit(run_job, job_name)
    return jsonify({"status": "accepted", "job": job_name}), 202


if __name__ == "__main__":  # pragma: no cover
    app.run(host="0.0.0.0", port=5000)