"""Initialize the MySQL database for the ETL project.

This script reads a SQL file containing the schema definitions and
executes it against the configured MySQL database.  It can be run
manually or invoked as part of a deployment.  The SQL file may
contain multiple statements separated by semicolons.

Usage
=====

    python -m etl_project.init_db --sql /path/to/schema.sql

The schema file path defaults to the value of the ``SCHEMA_SQL``
environment variable if not provided on the command line.
"""

import argparse
import os
from typing import List

import mysql.connector

from .config import mysql_dsn
from .common.logging import get_logger

logger = get_logger(__name__)


def execute_sql_file(conn: mysql.connector.MySQLConnection, sql_path: str) -> None:
    """Execute SQL statements from a file against an open connection."""
    with open(sql_path, "r", encoding="utf-8") as f:
        sql = f.read()
    # Split on semicolons; this is naive but works for most DDL files.
    statements: List[str] = [stmt.strip() for stmt in sql.split(";") if stmt.strip()]
    with conn.cursor() as cur:
        for stmt in statements:
            logger.debug("Executing SQL: %s", stmt[:60])
            cur.execute(stmt)
    conn.commit()


def main(argv: None | List[str] = None) -> None:
    parser = argparse.ArgumentParser(description="Initialize the ETL database schema")
    parser.add_argument(
        "--sql",
        dest="sql_file",
        default=os.getenv("SCHEMA_SQL"),
        help="Path to the SQL file containing the schema.  If omitted, uses SCHEMA_SQL env var.",
    )
    args = parser.parse_args(argv)
    sql_file = args.sql_file
    if not sql_file:
        parser.error("Schema SQL file must be provided via --sql or SCHEMA_SQL env var.")
    if not os.path.isfile(sql_file):
        parser.error(f"SQL file not found: {sql_file}")
    dsn = mysql_dsn()
    with mysql.connector.connect(**dsn) as conn:
        logger.info("Initializing database using %s", sql_file)
        execute_sql_file(conn, sql_file)
    logger.info("Database initialization complete")


if __name__ == "__main__":  # pragma: no cover
    main()