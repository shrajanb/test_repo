"""Functions to merge data from staging tables into core tables.

The upsert functions in this module implement example logic for merging rows
from staging tables into the dimension/fact tables.  Adjust the SQL
statements to match your schema.
"""

from __future__ import annotations

import json
import logging
from typing import Iterable, Mapping, Sequence, Tuple

import mysql.connector

from etl_project.config import mysql_dsn

logger = logging.getLogger(__name__)


def upsert_issues(rows: Iterable[Mapping[str, any]]) -> None:
    """Upsert Jira issues into the dimension and fact tables.

    This example expects the following target tables:
    * `dim_issue` with columns (issue_key, summary, status, assignee, updated_at)
    * `fact_issue_activity` with columns (issue_key, field_changed, old_value, new_value, change_at)
    """
    dsn = mysql_dsn()
    rows_list = list(rows)
    with mysql.connector.connect(**dsn) as conn:
        with conn.cursor() as cur:
            for row in rows_list:
                key = row.get("issue_key")
                summary = row.get("summary")
                status = row.get("status")
                assignee = row.get("assignee")
                updated_at = row.get("updated_at")
                cur.execute(
                    """
                    INSERT INTO dim_issue (issue_key, summary, status, assignee, updated_at)
                    VALUES (%s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        summary = VALUES(summary),
                        status = VALUES(status),
                        assignee = VALUES(assignee),
                        updated_at = VALUES(updated_at)
                    """,
                    (key, summary, status, assignee, updated_at),
                )
                # Insert fact rows if the record contains history.  For brevity we assume a list of changes.
                for change in row.get("changes", []):
                    cur.execute(
                        """
                        INSERT INTO fact_issue_activity (issue_key, field_changed, old_value, new_value, change_at)
                        VALUES (%s, %s, %s, %s, %s)
                        """,
                        (
                            key,
                            change.get("field"),
                            change.get("from"),
                            change.get("to"),
                            change.get("at"),
                        ),
                    )
        conn.commit()
    logger.debug("Upserted %s issues", len(rows_list))


def upsert_pull_requests(rows: Iterable[Mapping[str, any]]) -> None:
    """Upsert pull requests into the dimension table.

    This function accepts pull request objects from multiple sources (GitHub,
    Azure DevOps, Bitbucket, etc.) and attempts to map common field names.

    Expected target table: ``dim_pull_request`` with columns:
        - repo: string identifying the repository (e.g. owner/repo)
        - pr_number: integer or string ID of the pull request
        - title: pull request title
        - state: open/closed/merged or other status string
        - author: username or display name of the creator
        - updated_at: ISO timestamp of last update or creation
    """
    dsn = mysql_dsn()
    rows_list = list(rows)
    if not rows_list:
        return
    with mysql.connector.connect(**dsn) as conn:
        with conn.cursor() as cur:
            for row in rows_list:
                # Attempt to derive repository identifier
                repo = row.get("repo") or row.get("repository") or row.get("repo_full_name") or row.get("project")
                # Derive pull request number or ID
                pr_number = row.get("pr_number") or row.get("number") or row.get("pr_id")
                title = row.get("title")
                state = row.get("state") or row.get("status")
                author = row.get("author") or row.get("creator")
                # Use updated timestamps, falling back to creation timestamps
                updated_at = (
                    row.get("updated_at")
                    or row.get("updated")
                    or row.get("created")
                    or row.get("creationDate")
                )
                cur.execute(
                    """
                    INSERT INTO dim_pull_request (repo, pr_number, title, state, author, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        title = VALUES(title),
                        state = VALUES(state),
                        author = VALUES(author),
                        updated_at = VALUES(updated_at)
                    """,
                    (repo, pr_number, title, state, author, updated_at),
                )
        conn.commit()
    logger.debug("Upserted %s pull requests", len(rows_list))


def upsert_repos(rows: Iterable[Mapping[str, any]]) -> None:
    """Upsert repositories into a dimension table.

    Expected target table: ``dim_repo`` with columns (repo_full_name, name,
    is_private, updated_at).
    """
    dsn = mysql_dsn()
    rows_list = list(rows)
    if not rows_list:
        return
    with mysql.connector.connect(**dsn) as conn:
        with conn.cursor() as cur:
            for row in rows_list:
                full_name = row.get("full_name") or row.get("repo_full_name")
                name = row.get("name")
                is_private = row.get("is_private")
                updated_at = row.get("updated_on") or row.get("updated_at")
                cur.execute(
                    """
                    INSERT INTO dim_repo (repo_full_name, name, is_private, updated_at)
                    VALUES (%s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        name = VALUES(name),
                        is_private = VALUES(is_private),
                        updated_at = VALUES(updated_at)
                    """,
                    (full_name, name, is_private, updated_at),
                )
        conn.commit()
    logger.debug("Upserted %s repositories", len(rows_list))


def upsert_builds(rows: Iterable[Mapping[str, any]]) -> None:
    """Upsert Jenkins builds into a fact table.

    Expected target table: ``fact_build`` with columns
    (job_name, build_number, timestamp, result).
    """
    dsn = mysql_dsn()
    rows_list = list(rows)
    if not rows_list:
        return
    with mysql.connector.connect(**dsn) as conn:
        with conn.cursor() as cur:
            for row in rows_list:
                job_name = row.get("job_name")
                build_number = row.get("build_number")
                ts = row.get("timestamp")
                result = row.get("result")
                cur.execute(
                    """
                    INSERT INTO fact_build (job_name, build_number, timestamp, result)
                    VALUES (%s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        timestamp = VALUES(timestamp),
                        result = VALUES(result)
                    """,
                    (job_name, build_number, ts, result),
                )
        conn.commit()
    logger.debug("Upserted %s Jenkins builds", len(rows_list))


def upsert_work_items(rows: Iterable[Mapping[str, any]]) -> None:
    """Upsert Azure DevOps work items (pull requests) into dimension table.

    This simply proxies to ``upsert_pull_requests`` because the shape
    of the data is compatible.  The wrapper is provided for clarity.
    """
    upsert_pull_requests(rows)