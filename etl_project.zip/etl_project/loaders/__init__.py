"""Database loading functions.

This package contains functions to load raw data into staging tables
and merge them into core dimension and fact tables.  When writing
custom upsert logic for a new entity, add a function to
``upsert.py`` in this package.
"""

from .staging import insert_rows  # noqa: F401
from .upsert import (
    upsert_issues,
    upsert_pull_requests,
    upsert_repos,
    upsert_builds,
    upsert_work_items,
)  # noqa: F401