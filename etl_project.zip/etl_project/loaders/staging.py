"""Functions to write raw records into staging tables.

Staging tables mirror the shape of the raw data for each entity.  They have a
minimum set of columns including a unique identifier, the raw JSON payload and
an ingestion timestamp:

```
CREATE TABLE IF NOT EXISTS stg_example (
    id VARCHAR(64) PRIMARY KEY,
    payload JSON NOT NULL,
    ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

The upsert logic in `loaders/upsert.py` reads from staging tables and merges
records into the core tables.
"""

from __future__ import annotations

import json
import logging
from typing import Iterable, Mapping

import mysql.connector

from etl_project.config import mysql_dsn

logger = logging.getLogger(__name__)


def insert_rows(table: str, rows: Iterable[Mapping[str, any]], id_field: str = "id") -> None:
    """Insert raw rows into a staging table.

    Parameters
    ----------
    table: str
        Name of the staging table.
    rows: Iterable[Mapping[str, any]]
        Iterable of dictionaries representing raw records.  Each dictionary
        must contain an `id_field` key; the rest of the record will be
        stored as JSON in the `payload` column.
    id_field: str, optional
        Name of the key in each row to use as the primary key value (default: `id`).
    """
    dsn = mysql_dsn()
    # Materialise the iterable into a list to compute its length once and iterate.
    records = list(rows)
    with mysql.connector.connect(**dsn) as conn:
        with conn.cursor() as cur:
            for record in records:
                record_id = record.get(id_field)
                payload_json = json.dumps(record, default=str)
                cur.execute(
                    f"""
                    INSERT INTO {table} (id, payload)
                    VALUES (%s, %s)
                    ON DUPLICATE KEY UPDATE payload = VALUES(payload)
                    """,
                    (record_id, payload_json),
                )
        conn.commit()
    logger.debug("Inserted %s rows into %s", len(records), table)