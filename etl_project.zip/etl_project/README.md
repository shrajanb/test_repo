# ETL Job Framework

This repository provides a simple ETL (extract–transform–load) framework in Python.  It is designed to populate
a MySQL database from a variety of internal services such as Jira, GitHub, Bitbucket, Jenkins and Azure
DevOps.  The code is modular and can be executed on a one‑off basis or triggered remotely via an HTTP API.

## Project structure

```
etl_project/
├── README.md                 # You are reading this file
├── config.py                 # Centralised configuration and helpers
├── init_db.py                # Optional helper to initialise schema from a SQL file
├── main.py                   # Command‑line entrypoint for running jobs
├── api_server.py             # Flask server exposing HTTP endpoints to trigger jobs
├── connectors/               # Source‑specific connectors for pulling data
│   ├── __init__.py
│   ├── jira.py
│   ├── github.py
│   ├── bitbucket.py
│   ├── jenkins.py
│   └── azure_devops.py
├── loaders/                  # Code to persist data into staging tables and core tables
│   ├── __init__.py
│   ├── staging.py
│   └── upsert.py
├── common/                   # Shared utilities
│   ├── __init__.py
│   ├── checkpoints.py        # Checkpoint management for incremental loads
│   ├── http.py               # HTTP helpers with retry logic
│   └── logging.py            # Simple logging helper
└── jobs/                     # Job definitions for each source
    ├── __init__.py
    ├── jira_issues.py
    ├── github_prs.py
    ├── bitbucket_repos.py
    ├── jenkins_builds.py
    └── azure_devops_prs.py
```

### Configuration

Edit the variables in `config.py` to supply your MySQL connection parameters, API endpoints and tokens.  Sensitive
information should be provided via environment variables (e.g., `MYSQL_HOST`, `JIRA_TOKEN`) or external
secrets managers.  The defaults demonstrate how to read from the environment.

### Running a job manually

To run a job directly from the command line, install the required dependencies (see below) and invoke:

```bash
python3 -m etl_project.main jira_issues
python3 -m etl_project.main github_prs
```

The first positional argument is the name of the job module inside `jobs/`.  Each job is responsible for
fetching new or updated records and writing them to your MySQL tables.

### Triggering jobs remotely

The Flask application defined in `api_server.py` exposes an HTTP API for starting jobs.  Start the server
like this:

```bash
python3 -m etl_project.api_server
```

Then trigger a job via a POST request (e.g. using `curl`):

```bash
curl -X POST -H "Content-Type: application/json" \
     -d '{"job":"jira_issues"}' \
     http://localhost:5000/run
```

The server replies immediately (HTTP 202) but the job continues executing in the background using a thread pool.
All output is logged to the console and to the configured log handler.  Jobs are identified by the same
names used when running them via the command line (e.g. ``jira_issues``, ``github_prs``).

### Schema initialisation

An example schema file for all tables used by this project must be provided separately.  You mentioned
it resides at ``/Users/rajan/Downloads/all_databases_structure.sql``.  To initialise a new database, you can
execute:

```bash
python3 -m etl_project.init_db --sql /path/to/all_databases_structure.sql
```

This will connect to the MySQL server defined in ``config.py`` and execute the SQL statements contained in
the file.  Alternatively you can set the ``SCHEMA_SQL`` environment variable to point to your SQL file and
invoke the script without providing ``--sql``.

### Dependencies

The project relies on the following Python packages:

* `requests` for HTTP calls
* `mysql-connector-python` for connecting to MySQL
* `Flask` for the optional API server
* `tenacity` for retry logic

You can install them with:

```bash
pip install requests mysql-connector-python Flask tenacity
```

### Extending the framework

Each connector implements its own `fetch_incremental` method that yields dictionaries representing raw
records.  When adding a new source, create a new file under `connectors/` and implement a class with
a similar API.  Add a corresponding job file in `jobs/` that orchestrates extraction, staging and upsert
for that source.