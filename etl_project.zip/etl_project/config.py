"""Central configuration for the ETL framework.

Edit the variables below or override them with environment variables.  This module
exposes convenient functions to read configuration values at runtime.
"""

import os
from typing import Optional


class Settings:
    """Global settings loaded from the environment with sensible defaults."""

    # MySQL connection
    MYSQL_HOST: str = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_PORT: int = int(os.getenv("MYSQL_PORT", "3306"))
    MYSQL_USER: str = os.getenv("MYSQL_USER", "etl_user")
    MYSQL_PASSWORD: str = os.getenv("MYSQL_PASSWORD", "etl_password")
    MYSQL_DATABASE: str = os.getenv("MYSQL_DATABASE", "etl_db")

    # API tokens and endpoints
    JIRA_BASE: str = os.getenv("JIRA_BASE", "https://jira.example.com")
    JIRA_TOKEN: Optional[str] = os.getenv("JIRA_TOKEN")

    GITHUB_TOKEN: Optional[str] = os.getenv("GITHUB_TOKEN")
    GITHUB_ORG: str = os.getenv("GITHUB_ORG", "myorg")

    BITBUCKET_BASE: str = os.getenv("BITBUCKET_BASE", "https://api.bitbucket.org/2.0")
    BITBUCKET_TOKEN: Optional[str] = os.getenv("BITBUCKET_TOKEN")

    JENKINS_BASE: str = os.getenv("JENKINS_BASE", "https://jenkins.example.com")
    JENKINS_USER: Optional[str] = os.getenv("JENKINS_USER")
    JENKINS_API_TOKEN: Optional[str] = os.getenv("JENKINS_API_TOKEN")

    AZDO_ORG_URL: str = os.getenv("AZDO_ORG_URL", "https://dev.azure.com/myorg")
    AZDO_PAT: Optional[str] = os.getenv("AZDO_PAT")

    # Job concurrency (for API server)
    MAX_WORKERS: int = int(os.getenv("ETL_MAX_WORKERS", "4"))


settings = Settings()


def mysql_dsn() -> dict:
    """Return a dictionary of connection parameters for mysql-connector-python."""
    return {
        "host": settings.MYSQL_HOST,
        "port": settings.MYSQL_PORT,
        "user": settings.MYSQL_USER,
        "password": settings.MYSQL_PASSWORD,
        "database": settings.MYSQL_DATABASE,
        "autocommit": True,
    }