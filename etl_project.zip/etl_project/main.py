"""Entry point for running ETL jobs from the command line.

Example usage::

    python -m etl_project.main jira_issues

Available jobs are defined in ``jobs/__init__.py`` and referenced in
the ``JOBS`` dictionary below.  When adding a new job module, be sure
to add it to the dictionary.
"""

import argparse
import sys
from typing import Callable, Dict

from .common.logging import get_logger
from .jobs import (
    run_jira_issues,
    run_github_prs,
    run_bitbucket_repos,
    run_jenkins_builds,
    run_azure_devops_prs,
)

logger = get_logger(__name__)


JOBS: Dict[str, Callable[[], None]] = {
    "jira_issues": run_jira_issues,
    "github_prs": run_github_prs,
    "bitbucket_repos": run_bitbucket_repos,
    "jenkins_builds": run_jenkins_builds,
    "azure_devops_prs": run_azure_devops_prs,
}


def run_job(job_name: str) -> None:
    job = JOBS.get(job_name)
    if not job:
        logger.error("Unknown job: %s", job_name)
        sys.exit(1)
    logger.info("Running job: %s", job_name)
    job()


def main(argv: None | list[str] = None) -> None:
    parser = argparse.ArgumentParser(description="Run ETL jobs")
    parser.add_argument(
        "job",
        choices=list(JOBS.keys()),
        help="Name of the job to run",
    )
    args = parser.parse_args(argv)
    run_job(args.job)


if __name__ == "__main__":  # pragma: no cover
    main()