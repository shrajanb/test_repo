"""Persistent checkpointing for incremental ETL jobs.

Each job should call `get_checkpoint` at the beginning to obtain the last
processed timestamp or other cursor.  After successfully writing data, the job
should update the checkpoint via `set_checkpoint`.  Checkpoints are stored in
a MySQL table `etl_sync_state` with the following schema:

```sql
CREATE TABLE IF NOT EXISTS etl_sync_state (
    source VARCHAR(64) PRIMARY KEY,
    checkpoint VARCHAR(255) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

It is assumed that this table exists in your database.  See `init_db.py` for
table creation.
"""

from __future__ import annotations

import logging
from typing import Optional

import mysql.connector

from etl_project.config import mysql_dsn

logger = logging.getLogger(__name__)


def get_checkpoint(source: str) -> Optional[str]:
    """Return the stored checkpoint value for a source, or None if not present."""
    dsn = mysql_dsn()
    with mysql.connector.connect(**dsn) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT checkpoint FROM etl_sync_state WHERE source=%s", (source,))
            row = cur.fetchone()
            return row[0] if row else None


def set_checkpoint(source: str, checkpoint: str) -> None:
    """Upsert a checkpoint value for a source."""
    dsn = mysql_dsn()
    with mysql.connector.connect(**dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO etl_sync_state (source, checkpoint)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE checkpoint = VALUES(checkpoint)
                """,
                (source, checkpoint),
            )
        conn.commit()
    logger.debug("Updated checkpoint for %s to %s", source, checkpoint)