"""HTTP utilities with retry logic for API calls.

The functions defined here wrap `requests` and apply retries with exponential backoff
using the `tenacity` library.  Each connector should use these helpers to perform
robust network I/O.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import requests
from requests import Response
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

logger = logging.getLogger(__name__)


class APIError(Exception):
    """Custom exception raised for unexpected API responses."""

    def __init__(self, status_code: int, message: str):
        super().__init__(f"API returned {status_code}: {message}")
        self.status_code = status_code
        self.message = message


@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=1, max=16),
    retry=retry_if_exception_type((requests.exceptions.RequestException, APIError)),
    reraise=True,
)
def get(url: str, headers: Optional[Dict[str, str]] = None, params: Optional[Dict[str, Any]] = None) -> Response:
    """HTTP GET with retries and basic error handling.

    Raises APIError if the response status code is not 2xx.
    """
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    if not resp.ok:
        raise APIError(resp.status_code, resp.text)
    return resp


@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=1, max=16),
    retry=retry_if_exception_type((requests.exceptions.RequestException, APIError)),
    reraise=True,
)
def post(url: str, headers: Optional[Dict[str, str]] = None, json_body: Optional[Dict[str, Any]] = None) -> Response:
    """HTTP POST with retries and error handling."""
    resp = requests.post(url, headers=headers, json=json_body, timeout=30)
    if not resp.ok:
        raise APIError(resp.status_code, resp.text)
    return resp