"""Simple logging helper.

This module centralises log configuration for both command line executions and the Flask API server.
"""

import logging


def configure_logging(level: int = logging.INFO) -> None:
    """Configure root logger with a stream handler.

    Parameters
    ----------
    level: int
        Logging level (default: INFO)
    """
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )